# Simple-CRUD-CI3
CRUD Sederhana menggunakan CodeIgniter 3 dan Bootstrap

<h2>Instalasi</h2>
1. Clone atau Download repo ini.
2. Buat database dengan nama "ci3_master", lalu import database yang ada pada folder "db".
3. Buka halaman awal pada "host/[folder_anda]/home/lihatdata".

<h2>Latihan</h2>
1. Implementasikan pada Master Project Inventory
