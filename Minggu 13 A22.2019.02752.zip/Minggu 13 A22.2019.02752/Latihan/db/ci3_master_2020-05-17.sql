# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.5.5-10.1.30-MariaDB)
# Database: ci3_master
# Generation Time: 2020-05-17 13:55:30 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table mobil
# ------------------------------------------------------------

DROP TABLE IF EXISTS `mobil`;

CREATE TABLE `mobil` (
  `kdmobil` char(5) NOT NULL,
  `jenis` char(10) NOT NULL,
  `tahun` char(4) NOT NULL,
  `harga` int(8) NOT NULL,
  `nopol` char(10) DEFAULT NULL,
  PRIMARY KEY (`kdmobil`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `mobil` WRITE;
/*!40000 ALTER TABLE `mobil` DISABLE KEYS */;

INSERT INTO `mobil` (`kdmobil`, `jenis`, `tahun`, `harga`, `nopol`)
VALUES
	('AVP01','AVP','2006',400000,'B 1234 KL'),
	('SDH01','SEDAN','2000',300000,'B 1234 VB'),
	('SDS01','SEDAN','2003',350000,'B 1234 MN');

/*!40000 ALTER TABLE `mobil` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table penyewa
# ------------------------------------------------------------

DROP TABLE IF EXISTS `penyewa`;

CREATE TABLE `penyewa` (
  `nopen` char(5) NOT NULL,
  `nama` char(20) NOT NULL,
  `telp` char(15) NOT NULL,
  `alamat` char(10) DEFAULT NULL,
  PRIMARY KEY (`nopen`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `penyewa` WRITE;
/*!40000 ALTER TABLE `penyewa` DISABLE KEYS */;

INSERT INTO `penyewa` (`nopen`, `nama`, `telp`, `alamat`)
VALUES
	('P0001','NAHIYAH','77886293','DEPOK'),
	('P0002','ZAHRAH','98688181','JAKARTA'),
	('P0003','SAFITRI','45678888','DEPOK');

/*!40000 ALTER TABLE `penyewa` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table sewa
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sewa`;

CREATE TABLE `sewa` (
  `nokw` char(5) NOT NULL,
  `tglsewa` date NOT NULL,
  `kdmobil` char(5) NOT NULL,
  `nopen` char(5) NOT NULL,
  `lama` int(11) NOT NULL,
  `bayar` int(11) NOT NULL,
  PRIMARY KEY (`nokw`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `sewa` WRITE;
/*!40000 ALTER TABLE `sewa` DISABLE KEYS */;

INSERT INTO `sewa` (`nokw`, `tglsewa`, `kdmobil`, `nopen`, `lama`, `bayar`)
VALUES
	('KW001','2010-03-12','SDH01','P0001',3,900000),
	('KW002','2010-03-16','AVP01','P0001',2,800000),
	('KW003','2010-05-03','SDS01','P0003',2,700000);

/*!40000 ALTER TABLE `sewa` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
